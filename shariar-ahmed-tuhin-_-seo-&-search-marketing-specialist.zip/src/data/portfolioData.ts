export const PERSONAL_INFO = {
  name: 'Shariar Ahmed Tuhin',
  title: 'Aspiring SEO & Search Marketing Specialist',
  shortBio:
    'Dedicated to Technical SEO, on-page architecture, Generative Engine Optimization (GEO), and paid advertising. Based in Savar, Dhaka, Bangladesh.',
  aboutText: `I have been connected with digital marketing since 2023, with a growing focus on Search Engine Optimization since 2025. Over this time, I have developed a solid foundation in technical optimization, search strategies, and website performance.

My knowledge extends into modern Generative Engine Optimization (GEO), Answer Engine Optimization (AEO), and paid search through Google Ads and Meta Ads.

As a motivated fresher at the beginning of my career, I am actively seeking an internship or entry-level opportunity to apply my knowledge, gain hands-on experience, and contribute to a professional team.`,
  availability: 'Open to Internship & Entry-Level Opportunities',
  email: 'shariarahmedtuhin@gmail.com',
  phone: '+88 01621960504',
  phoneClean: '+8801621960504',
  whatsAppUrl:
    'https://wa.me/8801621960504?text=Hello%20Shariar,%20I%20reviewed%20your%20portfolio%20and%20would%20like%20to%20connect.',
  location: 'Savar, Dhaka, Bangladesh',
};

export interface SkillCategoryGroup {
  category: string;
  description: string;
  skills: { name: string; detail: string }[];
}

export const SKILL_GROUPS: SkillCategoryGroup[] = [
  {
    category: 'Technical SEO',
    description: 'Crawl efficiency, indexing integrity, and site architecture.',
    skills: [
      { name: 'Technical SEO Auditing', detail: 'Diagnosing crawl errors, HTTP status codes, and render barriers.' },
      { name: 'Google Search Console', detail: 'Coverage reporting, URL inspection, and performance analysis.' },
      { name: 'XML Sitemap Management', detail: 'Hierarchical structure, clean indexing, and search engine submission.' },
      { name: 'Robots.txt Configuration', detail: 'Directive authoring, crawl budget protection, and bot rules.' },
      { name: 'Duplicate Content Management', detail: 'Canonicalization (rel="canonical") and parameter handling.' },
      { name: 'Redirect Management', detail: '301/302 mappings, eliminating redirect chains, and resolving 404s.' },
      { name: 'Website Technical Optimization', detail: 'Core Web Vitals awareness, mobile friendliness, and clean code.' },
    ],
  },
  {
    category: 'On-Page SEO',
    description: 'Search intent alignment, semantic formatting, and content structure.',
    skills: [
      { name: 'On-Page SEO', detail: 'Title tag and meta description crafting, heading structure (H1–H3).' },
      { name: 'Content Optimization', detail: 'Search intent mapping, topical coverage, and featured snippet formatting.' },
      { name: 'Internal Linking Strategy', detail: 'Topic cluster architecture and contextual anchor text.' },
      { name: 'Website Structure Optimization', detail: 'Logical navigation hierarchy and shallow click depth.' },
    ],
  },
  {
    category: 'Modern Search Optimization',
    description: 'Generative search engines, answer discovery, and AI overviews.',
    skills: [
      { name: 'Generative Engine Optimization (GEO)', detail: 'Optimizing citations and entities for AI Overviews and LLM answers.' },
      { name: 'Answer Engine Optimization (AEO)', detail: 'Direct concise answers and Schema.org structured markup.' },
      { name: 'Search Strategy & Optimization', detail: 'Competitive query research and long-tail keyword planning.' },
    ],
  },
  {
    category: 'Paid Media',
    description: 'Targeted paid advertising and campaign fundamentals.',
    skills: [
      { name: 'Google Ads', detail: 'Search campaign structure, keyword match types, RSA copy, and negative lists.' },
      { name: 'Meta Ads', detail: 'Campaign objectives, audience targeting, and ad positioning in Meta Business Suite.' },
    ],
  },
  {
    category: 'Website & Implementation',
    description: 'Practical CMS setup and on-site implementation.',
    skills: [
      { name: 'WordPress-Based SEO Implementation', detail: 'Hands-on configuration with Yoast, RankMath, permalinks, and caching.' },
    ],
  },
];

export const EDUCATION_ITEMS = [
  {
    institution: 'Sena Public School and College',
    degree: 'Higher Secondary Certificate (HSC)',
    field: 'Science',
    graduationYear: '2026',
    gpa: '4.33',
    details: 'Science curriculum focused on analytical problem-solving and quantitative reasoning.',
  },
  {
    institution: 'Daffodil International School',
    degree: 'Secondary School Certificate (SSC)',
    field: 'General / Science',
    graduationYear: '2024',
    gpa: '5.00',
    details: 'Achieved a perfect GPA of 5.00 with academic distinction.',
  },
];

export const CAREER_TARGETS = [
  {
    title: 'SEO Internship Opportunities',
    detail: 'Hands-on execution of audits, keyword analysis, and on-page optimization under senior guidance.',
  },
  {
    title: 'Junior SEO Executive Positions',
    detail: 'Daily technical health monitoring, Search Console tracking, and content optimization workflows.',
  },
  {
    title: 'Entry-Level Search Marketing Roles',
    detail: 'Combined role supporting organic SEO, Google Ads search campaigns, and reporting.',
  },
  {
    title: 'Opportunities in GEO and AEO',
    detail: 'Specialized focus on preparing brand content for AI-powered search engines and answer engines.',
  },
];
