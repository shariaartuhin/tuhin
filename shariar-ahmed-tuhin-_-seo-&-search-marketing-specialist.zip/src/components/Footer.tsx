import React from 'react';
import { PERSONAL_INFO } from '../data/portfolioData';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="py-10 border-t border-zinc-200/80 dark:border-zinc-800/80 bg-zinc-50/50 dark:bg-zinc-950">
      <div className="max-w-5xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500 dark:text-zinc-400">
        <div>
          <span className="font-semibold text-zinc-900 dark:text-white">
            {PERSONAL_INFO.name}
          </span>
          <span className="mx-2">·</span>
          <span>{PERSONAL_INFO.title}</span>
          <span className="mx-2">·</span>
          <span>{PERSONAL_INFO.location}</span>
        </div>

        <div>
          <span>© {currentYear} Shariar Ahmed Tuhin. All rights reserved.</span>
        </div>
      </div>
    </footer>
  );
};
