import React from 'react';
import { PERSONAL_INFO } from '../data/portfolioData';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-16 md:py-20 border-b border-zinc-200/80 dark:border-zinc-800/80">
      <div className="max-w-5xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12">
          {/* Section Label */}
          <div className="md:col-span-4">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 dark:text-zinc-500 mb-1">
              About Me
            </h2>
            <p className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900 dark:text-white">
              Professional Journey
            </p>
          </div>

          {/* Clean Concise Text */}
          <div className="md:col-span-8 space-y-4 text-sm sm:text-base text-zinc-600 dark:text-zinc-400 leading-relaxed">
            <p>
              I have been connected with digital marketing since 2023, with a dedicated focus on Search Engine Optimization since 2025. Over this period, I have built a solid foundation in technical audits, on-page optimization, website performance, and search visibility.
            </p>
            <p>
              My focus extends beyond traditional search into Generative Engine Optimization (GEO), Answer Engine Optimization (AEO), and paid search advertising via Google Ads and Meta Ads.
            </p>
            <p>
              As a motivated fresher at the start of my professional career, I am actively seeking an internship or entry-level role where I can apply my knowledge, gain hands-on agency experience, and contribute to a professional team.
            </p>

            {/* Concise Highlights Grid */}
            <div className="pt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3.5 rounded-lg bg-zinc-50 dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800">
                <span className="font-semibold text-zinc-900 dark:text-white block mb-0.5">
                  Technical & On-Page SEO
                </span>
                <span className="text-zinc-500 dark:text-zinc-400">
                  Crawl auditing, indexing, robots.txt, sitemaps, and structure.
                </span>
              </div>

              <div className="p-3.5 rounded-lg bg-zinc-50 dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800">
                <span className="font-semibold text-zinc-900 dark:text-white block mb-0.5">
                  Modern Search (GEO & AEO)
                </span>
                <span className="text-zinc-500 dark:text-zinc-400">
                  Optimization for AI Overviews, entity signals, and direct answers.
                </span>
              </div>

              <div className="p-3.5 rounded-lg bg-zinc-50 dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800">
                <span className="font-semibold text-zinc-900 dark:text-white block mb-0.5">
                  Paid Advertising
                </span>
                <span className="text-zinc-500 dark:text-zinc-400">
                  Google Search Ads, match types, and Meta Ads Manager workflows.
                </span>
              </div>

              <div className="p-3.5 rounded-lg bg-zinc-50 dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800">
                <span className="font-semibold text-zinc-900 dark:text-white block mb-0.5">
                  Location & Availability
                </span>
                <span className="text-zinc-500 dark:text-zinc-400">
                  Based in Savar, Dhaka. Open to on-site, hybrid, and remote roles.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
