import React from 'react';
import { CAREER_TARGETS } from '../data/portfolioData';
import { ArrowUpRight } from 'lucide-react';

export const CareerGoalsSection: React.FC = () => {
  return (
    <section id="opportunities" className="py-16 md:py-20 border-b border-zinc-200/80 dark:border-zinc-800/80">
      <div className="max-w-5xl mx-auto px-6">
        <div className="mb-10">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 dark:text-zinc-500 mb-1">
            Career Opportunities
          </h2>
          <p className="text-2xl sm:text-3xl font-bold tracking-tight text-zinc-900 dark:text-white">
            What I'm Looking For
          </p>
          <p className="mt-2 text-sm text-zinc-600 dark:text-zinc-400 max-w-xl">
            Seeking opportunities to apply search optimization knowledge, learn from experienced practitioners, and deliver measurable value.
          </p>
        </div>

        {/* 4 Clean Targeted Roles */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
          {CAREER_TARGETS.map((target) => (
            <div
              key={target.title}
              className="p-5 rounded-xl bg-zinc-50/60 dark:bg-zinc-900/40 border border-zinc-200/80 dark:border-zinc-800/80"
            >
              <h3 className="text-sm font-bold text-zinc-900 dark:text-white mb-1.5">
                {target.title}
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed">
                {target.detail}
              </p>
            </div>
          ))}
        </div>

        {/* Simple Statement Banner with CTA */}
        <div className="p-6 sm:p-8 rounded-xl bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <blockquote className="text-sm sm:text-base font-medium leading-relaxed max-w-xl">
            "I'm looking for an opportunity to turn my knowledge into practical experience, contribute to a professional team, and continue developing my expertise in the evolving search marketing industry."
          </blockquote>

          <a
            href="#contact"
            className="inline-flex items-center gap-1.5 px-5 py-2.5 text-xs font-semibold bg-white text-zinc-900 hover:bg-zinc-100 dark:bg-zinc-900 dark:text-white dark:hover:bg-zinc-800 rounded-md transition-colors whitespace-nowrap shrink-0"
          >
            <span>Let's Connect</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </section>
  );
};
