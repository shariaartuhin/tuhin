import React from 'react';
import { SKILL_GROUPS } from '../data/portfolioData';

export const SkillsSection: React.FC = () => {
  return (
    <section id="skills" className="py-16 md:py-20 border-b border-zinc-200/80 dark:border-zinc-800/80">
      <div className="max-w-5xl mx-auto px-6">
        <div className="mb-12">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 dark:text-zinc-500 mb-1">
            Core Competencies
          </h2>
          <p className="text-2xl sm:text-3xl font-bold tracking-tight text-zinc-900 dark:text-white">
            Skills & Expertise
          </p>
          <p className="mt-2 text-sm text-zinc-600 dark:text-zinc-400 max-w-xl">
            Systematic search knowledge covering technical infrastructure, on-page optimization, generative search engines, and paid campaigns.
          </p>
        </div>

        {/* 5 Distinct Clean Categories */}
        <div className="space-y-8">
          {SKILL_GROUPS.map((group) => (
            <div
              key={group.category}
              className="p-6 rounded-xl bg-zinc-50/60 dark:bg-zinc-900/40 border border-zinc-200/80 dark:border-zinc-800/80"
            >
              <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 mb-4 pb-3 border-b border-zinc-200/60 dark:border-zinc-800/60">
                <h3 className="text-base font-bold text-zinc-900 dark:text-white">
                  {group.category}
                </h3>
                <span className="text-xs text-zinc-500 dark:text-zinc-400">
                  {group.description}
                </span>
              </div>

              {/* Clean Scannable Skills List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {group.skills.map((skill) => (
                  <div
                    key={skill.name}
                    className="p-3 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200/60 dark:border-zinc-800"
                  >
                    <span className="text-xs font-semibold text-zinc-900 dark:text-white block mb-0.5">
                      {skill.name}
                    </span>
                    <span className="text-2xs text-zinc-500 dark:text-zinc-400 leading-normal block">
                      {skill.detail}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
