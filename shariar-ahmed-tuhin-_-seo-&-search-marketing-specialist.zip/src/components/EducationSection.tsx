import React from 'react';
import { EDUCATION_ITEMS } from '../data/portfolioData';

export const EducationSection: React.FC = () => {
  return (
    <section id="education" className="py-16 md:py-20 border-b border-zinc-200/80 dark:border-zinc-800/80">
      <div className="max-w-5xl mx-auto px-6">
        <div className="mb-10">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 dark:text-zinc-500 mb-1">
            Academic Background
          </h2>
          <p className="text-2xl sm:text-3xl font-bold tracking-tight text-zinc-900 dark:text-white">
            Education
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {EDUCATION_ITEMS.map((item) => (
            <div
              key={item.institution}
              className="p-6 rounded-xl bg-zinc-50/60 dark:bg-zinc-900/40 border border-zinc-200/80 dark:border-zinc-800/80 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
                    Graduation: {item.graduationYear}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-zinc-200/70 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200">
                    GPA: {item.gpa}
                  </span>
                </div>

                <h3 className="text-base sm:text-lg font-bold text-zinc-900 dark:text-white mb-0.5">
                  {item.institution}
                </h3>

                <p className="text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-3">
                  {item.degree} {item.field && `· ${item.field}`}
                </p>

                <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed">
                  {item.details}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
