import React from 'react';
import { ArrowDown, ArrowUpRight, MessageCircle } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

export const HeroSection: React.FC = () => {
  return (
    <section id="home" className="pt-28 pb-16 md:pt-36 md:pb-24 border-b border-zinc-200/80 dark:border-zinc-800/80">
      <div className="max-w-5xl mx-auto px-6">
        <div className="flex flex-col-reverse md:flex-row items-center justify-between gap-10 md:gap-16">
          {/* Left Text Column */}
          <div className="flex-1 text-center md:text-left">
            {/* Availability Indicator */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
              <span>{PERSONAL_INFO.availability}</span>
            </div>

            {/* Name & Title in clean Inter */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-zinc-900 dark:text-white leading-tight mb-2">
              {PERSONAL_INFO.name}
            </h1>

            <p className="text-lg sm:text-xl font-medium text-zinc-600 dark:text-zinc-400 mb-5">
              {PERSONAL_INFO.title}
            </p>

            {/* Concise Bio */}
            <p className="text-sm sm:text-base text-zinc-600 dark:text-zinc-400 max-w-lg leading-relaxed mb-8">
              {PERSONAL_INFO.shortBio}
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3">
              <a
                href="#skills"
                className="inline-flex items-center gap-1.5 px-5 py-2.5 text-xs font-semibold text-white bg-zinc-900 dark:bg-zinc-100 dark:text-zinc-900 rounded-md hover:bg-zinc-800 dark:hover:bg-zinc-200 transition-colors"
              >
                <span>Explore Skills</span>
                <ArrowDown className="w-3.5 h-3.5" />
              </a>

              <a
                href="#contact"
                className="inline-flex items-center gap-1.5 px-5 py-2.5 text-xs font-semibold text-zinc-800 dark:text-zinc-200 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-md hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-colors"
              >
                <span>Get in Touch</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>

              <a
                href={PERSONAL_INFO.whatsAppUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold text-zinc-700 dark:text-zinc-300 hover:text-emerald-600 dark:hover:text-emerald-400 border border-transparent hover:border-zinc-200 dark:hover:border-zinc-800 rounded-md transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>

          {/* Right: The Single Profile Photograph in a Circular Mask */}
          <div className="shrink-0">
            <div className="w-48 h-48 sm:w-56 sm:h-56 md:w-64 md:h-64 rounded-full overflow-hidden p-1.5 bg-zinc-100 dark:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-700/80 shadow-xs">
              <img
                src="/assets/profile_shariar.jpg"
                alt="Shariar Ahmed Tuhin - Aspiring SEO & Search Marketing Specialist"
                className="w-full h-full object-cover object-[center_12%] rounded-full"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  const target = e.currentTarget;
                  if (!target.src.includes('650776AB-41C1-4C8A-A7C9-E82468885D94.jpg')) {
                    target.src = 'https://i.postimg.cc/6q7xT2xK/650776AB-41C1-4C8A-A7C9-E82468885D94.jpg';
                  }
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
